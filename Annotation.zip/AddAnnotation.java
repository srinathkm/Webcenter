import java.io.*;
import oracle.stellent.ridc.*;
import oracle.stellent.ridc.model.*;
import oracle.stellent.ridc.protocol.*;
import oracle.stellent.ridc.protocol.intradoc.*;
import oracle.stellent.ridc.common.log.*;
import oracle.stellent.ridc.model.serialize.*;
import oracle.stellent.ridc.protocol.http.*;
import java.util.List;
import java.util.*;
import java.text.*;

/*

*@Author : Srinath Menon
*@Date : 01/12/2015
*@Description : This class will add a annotation to existing documents based on a template (annotation file) 
*               This action from UI is available from ADF UI and it is included from wcc version 12.2.1.0.0 as part of imaging 
*               application functionalities merged to core wcc server.
*@Params : annotationFile - this is the template xml file which sets the "text" , "location" and other details for the annotation.
           In this example class the file is copied from another content where annotation has already been done from ADF UI.

*/
public class AddAnnotation {

	/**
	 * @param args
	 */
        private static  String Rendition="";

	public static void main(String[] args) {


   	        // Create a new IdcClientManager
                                
                IdcClientManager manager = new IdcClientManager ();
                Properties prop = new Properties();
                InputStream input = null;

                try{

                        input = new FileInputStream("config.file");

                        //Load Properties file to read connection details
                        prop.load(input);

                        // Create a new IdcClient Connection
                        IdcClient idcClient = manager.createClient (prop.getProperty("IDC_PROTOCOL")+"://" + prop.getProperty("RIDC_SERVER") + ":" + prop.getProperty("RIDC_PORT"));
                        IdcContext userContext = new IdcContext(prop.getProperty("user"));
  
                        
			// Create an HdaBinderSerializer; this is not necessary, but it allows us to serialize the request and response data binders
			HdaBinderSerializer serializer = new HdaBinderSerializer ("UTF-8", idcClient.getDataFactory ());
			
			// Databinder for setting the annotation
			DataBinder dataBinder = idcClient.createBinder();
                        dataBinder.putLocal("IdcService", "EDIT_RENDITIONS");
                        dataBinder.putLocal("dID",prop.getProperty("dID"));
                        dataBinder.putLocal("AuxRenditionType","System");
                        dataBinder.putLocal("addRendition0.action","edit");
                        dataBinder.putLocal("addRendition0.name","annotationRendition");
                        dataBinder.putLocal("renditionKeys","addRendition0");
                        dataBinder.putLocal("addRendition0.description",prop.getProperty("description"));
                        dataBinder.addFile("addRendition0.file",new File(prop.getProperty("annotationFile")));
            
            // Write the data binder for the request to stdout
            serializer.serializeBinder (System.out, dataBinder);
            // Send the request to Content Server
            ServiceResponse response = idcClient.sendRequest(userContext,dataBinder);
            // Get the data binder for the response from Content Server
            DataBinder responseData = response.getResponseAsBinder();
            // Write the response data binder to stdout
            serializer.serializeBinder (System.out, responseData);


		} catch (IdcClientException ice){
			ice.printStackTrace();
		} catch (IOException ioe){
			ioe.printStackTrace();
		}
	}

}


HideStatus Component

This component when enabled would hide the dStatus metadata from Content
Information Page . 

By default, like other metadata's the field cannot be hidden using isHidden
idoc script but needs dynamic html to be overridden. 

